import { AlertCircle, Lock, TrendingDown } from "lucide-react";

const problems = [
  {
    icon: TrendingDown,
    title: "Impacto Financeiro Devastador",
    description:
      "Uma única condenação trabalhista pode comprometer o lucro de meses de trabalho duro. Quanto custou o último processo que sua empresa perdeu?",
    color: "text-secondary",
  },
  {
    icon: AlertCircle,
    title: "Riscos Ocultos",
    description:
      "Contratos mal redigidos e falta de conformidade são bombas-relógio prontas para explodir. A ausência de prevenção jurídica cria exposição constante.",
    color: "text-primary",
  },
  {
    icon: Lock,
    title: "Insegurança Operacional",
    description:
      "Tomar decisões de demissão, contratação ou parcerias sem respaldo jurídico coloca todo o patrimônio em risco permanente.",
    color: "text-accent",
  },
];

export default function Problem() {
  return (
    <section id="problema" className="py-20 md:py-32 bg-card">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            O custo invisível que está corroendo o seu caixa
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Empresários odeiam surpresas financeiras. A falta de segurança
            jurídica transforma cada decisão operacional em um risco calculado.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {problems.map((problem, index) => {
            const Icon = problem.icon;
            return (
              <div
                key={index}
                className="bg-background border border-border rounded-lg p-8 hover:border-primary/50 transition-all duration-300 group"
              >
                <div className="mb-6">
                  <Icon
                    size={32}
                    className={`${problem.color} group-hover:scale-110 transition-transform`}
                  />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  {problem.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {problem.description}
                </p>
              </div>
            );
          })}
        </div>

        <div className="mt-16 bg-background border border-border rounded-lg p-8 md:p-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-primary mb-4">
                Sua empresa não pode ser refém da insegurança jurídica
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                A advocacia reativa (apagar incêndios) é cara, lenta e
                imprevisível. A falta de suporte preventivo gera riscos
                desnecessários em cada contratação ou parceria.
              </p>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-secondary font-bold">✓</span>
                </div>
                <div>
                  <p className="font-semibold text-foreground">
                    Advocacia Reativa
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Apagar incêndios é caro e lento
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-secondary font-bold">✓</span>
                </div>
                <div>
                  <p className="font-semibold text-foreground">
                    Falta de Suporte
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Riscos em cada decisão operacional
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-secondary font-bold">✓</span>
                </div>
                <div>
                  <p className="font-semibold text-foreground">
                    Decisões Frágeis
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Patrimônio em risco constante
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
