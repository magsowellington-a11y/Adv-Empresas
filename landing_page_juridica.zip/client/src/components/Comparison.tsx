import { CheckCircle, X } from "lucide-react";

const comparisonData = [
  {
    feature: "Abordagem",
    traditional: "Advogado apaga incêndio",
    mensalista: "Advocacia preventiva",
  },
  {
    feature: "Custos",
    traditional: "Variáveis e imprevisíveis",
    mensalista: "Fixo mensal planejado",
  },
  {
    feature: "Atendimento",
    traditional: "Respostas lentas",
    mensalista: "Prioridade total",
  },
  {
    feature: "Proteção",
    traditional: "Alta exposição a riscos",
    mensalista: "Empresa blindada",
  },
  {
    feature: "Consultoria",
    traditional: "Pontual e reativa",
    mensalista: "Estratégica e contínua",
  },
  {
    feature: "Prevenção",
    traditional: "Inexistente",
    mensalista: "Foco principal",
  },
];

const benefits = [
  {
    title: "Orçamento Previsível",
    description: "Planejamento financeiro sem surpresas",
  },
  {
    title: "Atendimento Prioritário",
    description: "Sua empresa é prioridade sempre",
  },
  {
    title: "Proteção Contínua",
    description: "Blindagem jurídica 24/7",
  },
];

export default function Comparison() {
  return (
    <section id="vantagens" className="py-20 md:py-32 bg-card">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            Por que o modelo Mensalista é o melhor para sua EMPRESA
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Comparação clara entre advocacia tradicional e o modelo estratégico
            mensalista.
          </p>
        </div>

        <div className="overflow-x-auto mb-16">
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-border">
                <th className="text-left py-4 px-6 font-bold text-foreground">
                  Aspecto
                </th>
                <th className="text-center py-4 px-6 font-bold text-accent">
                  Modelo Tradicional
                </th>
                <th className="text-center py-4 px-6 font-bold text-primary">
                  Modelo Mensalista
                </th>
              </tr>
            </thead>
            <tbody>
              {comparisonData.map((row, index) => (
                <tr
                  key={index}
                  className="border-b border-border hover:bg-background/50 transition-colors"
                >
                  <td className="py-6 px-6 font-semibold text-foreground">
                    {row.feature}
                  </td>
                  <td className="py-6 px-6 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <X size={18} className="text-accent" />
                      <span className="text-muted-foreground">
                        {row.traditional}
                      </span>
                    </div>
                  </td>
                  <td className="py-6 px-6 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <CheckCircle size={18} className="text-secondary" />
                      <span className="text-primary font-medium">
                        {row.mensalista}
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="bg-gradient-to-r from-primary/5 to-secondary/5 border border-primary/20 rounded-lg p-8 md:p-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-primary mb-4">
                Previsibilidade Financeira
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Com custos fixos mensais, você planeja o orçamento jurídico com
                precisão, eliminando surpresas financeiras que comprometem o
                caixa.
              </p>
            </div>
            <div className="space-y-4">
              {benefits.map((benefit, index) => (
                <div
                  key={index}
                  className="bg-background border border-border rounded-lg p-4"
                >
                  <p className="font-semibold text-foreground mb-1">
                    {benefit.title}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {benefit.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
