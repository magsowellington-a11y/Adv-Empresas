import { Mail, MapPin, Phone } from "lucide-react";

const LOGO_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663205769547/KsM5B6D63hdNtGgcdC8sjV/Gemini_Generated_Image_bui058bui058bui0_d72175c1.png";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-white text-primary border-t border-primary/20">
      <div className="container py-12 md:py-16">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div className="space-y-4">
            <img
              src={LOGO_URL}
              alt="Magsowellington Alves - Advocacia"
              className="h-32 w-auto"
            />
            <p className="text-sm text-primary/80 leading-relaxed">
              Blindagem jurídica estratégica para empresas em Goiás.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-4">Navegação</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href="#problema"
                  className="text-primary/80 hover:text-primary transition-colors"
                >
                  O Problema
                </a>
              </li>
              <li>
                <a
                  href="#solucao"
                  className="text-primary/80 hover:text-primary transition-colors"
                >
                  A Solução
                </a>
              </li>
              <li>
                <a
                  href="#vantagens"
                  className="text-primary/80 hover:text-primary transition-colors"
                >
                  Vantagens
                </a>
              </li>
              <li>
                <a
                  href="#especialista"
                  className="text-primary/80 hover:text-primary transition-colors"
                >
                  Especialista
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Serviços</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href="#"
                  className="text-primary/80 hover:text-primary transition-colors"
                >
                  Blindagem Trabalhista
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-primary/80 hover:text-primary transition-colors"
                >
                  Consultoria Estratégica
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-primary/80 hover:text-primary transition-colors"
                >
                  Gestão Contratual
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-primary/80 hover:text-primary transition-colors"
                >
                  Defesa Judicial
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Contato</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2">
                <Phone size={16} />
                <span className="text-primary/80">(62) 99976-4131</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail size={16} />
                <span className="text-primary/80">
                  magsowellington@gmail.com
                </span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin size={16} className="mt-0.5" />
                <span className="text-primary/80">
                  Av. T-3, Qd. 16 - LT. 14 - St. Bueno, Goiânia - GO,
                  74215-110
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-primary/20 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-primary/70">
            <p>
              © {currentYear} Dr. Magsowellington Alves. Todos os direitos
              reservados.
            </p>
            <div className="flex items-center gap-6">
              <a
                href="#"
                className="hover:text-primary transition-colors"
              >
                Política de Privacidade
              </a>
              <a
                href="#"
                className="hover:text-primary transition-colors"
              >
                Termos de Serviço
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
