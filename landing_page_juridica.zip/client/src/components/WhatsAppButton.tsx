import { MessageCircle, X } from "lucide-react";
import { useState } from "react";

export default function WhatsAppButton() {
  const [isOpen, setIsOpen] = useState(false);
  const whatsappLink = `https://wa.me/5562999764131?text=${encodeURIComponent(
    "Olá! Gostaria de agendar um diagnóstico jurídico gratuito para minha empresa."
  )}`;

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const openWhatsApp = () => {
    window.open(whatsappLink, "_blank");
    setIsOpen(false);
  };

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 z-30"
          onClick={() => setIsOpen(false)}
        />
      )}
      <div className="fixed bottom-6 left-6 z-40 flex flex-col items-start gap-3">
        {isOpen && (
          <div className="bg-background border border-border rounded-lg shadow-lg p-4 max-w-xs animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="space-y-3">
              <div>
                <p className="font-semibold text-foreground text-sm mb-2">
                  Fale conosco no WhatsApp
                </p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  (62) 99976-4131 - Responderemos em poucos minutos durante o horário comercial
                </p>
              </div>
              <button
                onClick={openWhatsApp}
                className="w-full px-4 py-3 bg-green-500 text-white rounded-lg font-semibold hover:bg-green-600 transition-colors flex items-center justify-center gap-2 text-sm"
              >
                <MessageCircle size={18} />
                Abrir WhatsApp
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="w-full px-4 py-2 bg-muted text-foreground rounded-lg font-medium hover:bg-muted/80 transition-colors text-sm"
              >
                Fechar
              </button>
            </div>
          </div>
        )}
        <button
          onClick={toggleMenu}
          className={`w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition-all duration-300 ${
            isOpen
              ? "bg-primary text-primary-foreground"
              : "bg-green-500 text-white hover:bg-green-600 hover:scale-110"
          }`}
          title="Contato via WhatsApp"
        >
          {isOpen ? (
            <X size={24} />
          ) : (
            <MessageCircle size={24} />
          )}
        </button>
      </div>
      <style>{`
        @keyframes slide-in-from-bottom-2 {
          from {
            opacity: 0;
            transform: translateY(8px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-in {
          animation: slide-in-from-bottom-2 0.3s ease-out;
        }
        .fade-in {
          animation: fade-in 0.3s ease-out;
        }
        @keyframes fade-in {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
      `}</style>
    </>
  );
}
