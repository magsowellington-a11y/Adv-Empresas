import { MapPin, Briefcase, TrendingUp } from "lucide-react";

const SPECIALIST_IMAGE_URL = "/manus-storage/DrW(2)_50d560aa.webp";

const specialties = [
  {
    icon: MapPin,
    title: "Atuação em Goiás",
    description: "Especialista na realidade do empresariado local",
  },
  {
    icon: Briefcase,
    title: "Foco Empresarial",
    description: "Experiência com empresas de todos os tamanhos",
  },
  {
    icon: TrendingUp,
    title: "Parceria de Longo Prazo",
    description: "Crescimento contínuo e sustentável juntos",
  },
];

export default function Specialist() {
  return (
    <section id="especialista" className="py-20 md:py-32 bg-background">
      <div className="container">
        <div className="max-w-5xl mx-auto">
          <div className="bg-card border border-border rounded-lg p-8 md:p-12 mb-12">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="flex items-center justify-center order-2 md:order-1">
                <div className="relative w-full max-w-sm">
                  <div className="relative rounded-xl overflow-hidden shadow-xl border-4 border-primary/20">
                    <img
                      src={SPECIALIST_IMAGE_URL}
                      alt="Dr. Magsowellington Alves"
                      className="w-full h-auto object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent" />
                  </div>
                  <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-secondary/10 rounded-full blur-2xl" />
                  <div className="absolute -top-4 -left-4 w-32 h-32 bg-primary/10 rounded-full blur-2xl" />
                </div>
              </div>

              <div className="space-y-6 order-1 md:order-2">
                <h2 className="text-4xl md:text-5xl font-bold text-primary">
                  Dr. Magsowellington Alves
                </h2>

                <div className="border-l-4 border-secondary pl-6 py-4 bg-secondary/5 rounded-r-lg">
                  <p className="text-lg italic text-foreground">
                    "Entendemos a realidade do empresariado em Goiás. Nossa
                    missão é garantir que você foque em vender e crescer,
                    enquanto nós cuidamos da segurança da sua operação."
                  </p>
                </div>

                <p className="text-muted-foreground leading-relaxed">
                  Mais do que advogados, somos estrategistas jurídicos
                  comprometidos com a sustentabilidade e o lucro do seu
                  negócio. Cada decisão é tomada com foco no crescimento seguro
                  da sua empresa.
                </p>

                <div className="pt-4 space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-secondary text-sm font-bold">✓</span>
                    </div>
                    <p className="text-foreground">
                      Especialista em Blindagem Trabalhista e Assessoria
                      Estratégica
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-secondary text-sm font-bold">✓</span>
                    </div>
                    <p className="text-foreground">
                      Experiência comprovada com empresas de todos os tamanhos
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-secondary text-sm font-bold">✓</span>
                    </div>
                    <p className="text-foreground">
                      Disponível para consultoria estratégica e suporte contínuo
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {specialties.map((specialty, index) => {
              const Icon = specialty.icon;
              return (
                <div
                  key={index}
                  className="bg-card border border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors"
                >
                  <Icon size={32} className="text-primary mx-auto mb-3" />
                  <h3 className="font-bold text-foreground mb-2">
                    {specialty.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {specialty.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
