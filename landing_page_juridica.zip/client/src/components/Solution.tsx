import {
  Shield,
  Clock,
  FileText,
  Gavel,
} from "lucide-react";

const solutions = [
  {
    icon: Shield,
    title: "Blindagem Trabalhista",
    description:
      "Auditoria completa de contratos, revisão de procedimentos internos e redução drástica de passivo trabalhista através de conformidade rigorosa.",
    features: [
      "Auditoria de contratos",
      "Revisão de procedimentos",
      "Redução de passivo",
    ],
  },
  {
    icon: Clock,
    title: "Consultoria em Tempo Real",
    description:
      "Respostas rápidas e precisas para demissões, contratações e parcerias. Suporte direto ao empresário com prioridade total.",
    features: ["Respostas ágeis", "Prioridade 24h", "Suporte estratégico"],
  },
  {
    icon: FileText,
    title: "Gestão Contratual",
    description:
      "Elaboração e revisão técnica de contratos com fornecedores, parceiros e clientes. Eliminação de brechas jurídicas.",
    features: [
      "Contratos blindados",
      "Revisão técnica",
      "Padronização",
    ],
  },
  {
    icon: Gavel,
    title: "Defesa de Interesses",
    description:
      "Atuação em processos judiciais e administrativos com foco total na redução de danos e preservação de caixa.",
    features: [
      "Defesa estratégica",
      "Redução de danos",
      "Acordos inteligentes",
    ],
  },
];

export default function Solution() {
  return (
    <section id="solucao" className="py-20 md:py-32 bg-background">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            A Solução: Advocacia Preventiva e Estratégica para sua EMPRESA
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed mb-8">
            Apresentamos o modelo de Assessoria Mensalista: um investimento fixo
            com retorno imediato em segurança patrimonial.
          </p>
          <p className="text-lg font-semibold text-secondary">
            Foco total na prevenção de riscos e proteção do patrimônio da sua
            empresa
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {solutions.map((solution, index) => {
            const Icon = solution.icon;
            return (
              <div
                key={index}
                className="bg-card border border-border rounded-lg p-8 hover:border-primary/50 transition-all duration-300 group"
              >
                <div className="mb-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <Icon size={32} className="text-primary" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-3">
                  {solution.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  {solution.description}
                </p>
                <ul className="space-y-2">
                  {solution.features.map((feature, idx) => (
                    <li
                      key={idx}
                      className="flex items-center gap-2 text-sm text-foreground"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-secondary" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        <div className="bg-gradient-to-r from-primary/5 to-secondary/5 border border-primary/20 rounded-lg p-8 md:p-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-primary mb-4">
                Modelo Mensalista: Investimento, não Custo
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Com um valor mensal fixo e previsível, sua empresa tem acesso a
                um departamento jurídico estratégico completo, focado em
                prevenção e crescimento seguro.
              </p>
            </div>
            <div className="space-y-4">
              <div className="bg-background border border-border rounded-lg p-4">
                <p className="font-semibold text-foreground mb-1">
                  Foco em Prevenção
                </p>
                <p className="text-sm text-muted-foreground">
                  Evitar problemas é mais barato que resolvê-los
                </p>
              </div>
              <div className="bg-background border border-border rounded-lg p-4">
                <p className="font-semibold text-foreground mb-1">
                  Custo Previsível
                </p>
                <p className="text-sm text-muted-foreground">
                  Orçamento jurídico sem surpresas
                </p>
              </div>
              <div className="bg-background border border-border rounded-lg p-4">
                <p className="font-semibold text-foreground mb-1">
                  Parceria Contínua
                </p>
                <p className="text-sm text-muted-foreground">
                  Especialista dedicado ao seu negócio
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
