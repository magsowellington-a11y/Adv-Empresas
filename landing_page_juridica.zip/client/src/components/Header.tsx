import { Menu, X } from "lucide-react";
import { useState } from "react";

const LOGO_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663205769547/KsM5B6D63hdNtGgcdC8sjV/Gemini_Generated_Image_bui058bui058bui0_d72175c1.png";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-background border-b border-border">
      <div className="container flex items-center justify-between h-20">
        <a
          href="#"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="flex items-center gap-2 hover:opacity-80 transition-opacity"
        >
          <img
            src={LOGO_URL}
            alt="Magsowellington Alves - Advocacia"
            className="h-20 w-auto"
          />
        </a>

        <nav className="hidden md:flex items-center gap-8">
          <button
            onClick={() => scrollToSection("problema")}
            className="text-foreground hover:text-primary transition-colors text-sm font-medium"
          >
            O Problema
          </button>
          <button
            onClick={() => scrollToSection("solucao")}
            className="text-foreground hover:text-primary transition-colors text-sm font-medium"
          >
            A Solução
          </button>
          <button
            onClick={() => scrollToSection("vantagens")}
            className="text-foreground hover:text-primary transition-colors text-sm font-medium"
          >
            Vantagens
          </button>
          <button
            onClick={() => scrollToSection("especialista")}
            className="text-foreground hover:text-primary transition-colors text-sm font-medium"
          >
            Especialista
          </button>
        </nav>

        <div className="hidden md:block">
          <button
            onClick={() => scrollToSection("cta")}
            className="px-6 py-2 bg-secondary text-secondary-foreground rounded-md font-semibold hover:opacity-90 transition-colors text-sm"
          >
            Diagnóstico Grátis
          </button>
        </div>

        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden p-2 hover:bg-muted rounded-md transition-colors"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-background">
          <nav className="container py-4 flex flex-col gap-4">
            <button
              onClick={() => scrollToSection("problema")}
              className="text-left text-foreground hover:text-primary transition-colors font-medium"
            >
              O Problema
            </button>
            <button
              onClick={() => scrollToSection("solucao")}
              className="text-left text-foreground hover:text-primary transition-colors font-medium"
            >
              A Solução
            </button>
            <button
              onClick={() => scrollToSection("vantagens")}
              className="text-left text-foreground hover:text-primary transition-colors font-medium"
            >
              Vantagens
            </button>
            <button
              onClick={() => scrollToSection("especialista")}
              className="text-left text-foreground hover:text-primary transition-colors font-medium"
            >
              Especialista
            </button>
            <button
              onClick={() => scrollToSection("cta")}
              className="text-left px-6 py-2 bg-secondary text-secondary-foreground rounded-md font-semibold hover:opacity-90 transition-colors text-sm"
            >
              Diagnóstico Grátis
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
