import { ArrowRight, CheckCircle } from "lucide-react";

const DOCTOR_IMAGE_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663205769547/KsM5B6D63hdNtGgcdC8sjV/DrW_22e602fc.png";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative py-20 md:py-32 bg-background overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/5 rounded-full blur-3xl -z-10" />

      <div className="container grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-bold text-primary leading-tight">
              Pare de perder lucro com processos trabalhistas evitáveis
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Sua empresa merece uma blindagem jurídica completa e estratégica.
              Transforme o jurídico de um custo inesperado em um investimento de
              proteção.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={() => scrollToSection("cta")}
              className="px-8 py-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition-all duration-300 flex items-center justify-center gap-2 group"
            >
              Quero um Diagnóstico
              <ArrowRight
                size={20}
                className="group-hover:translate-x-1 transition-transform"
              />
            </button>
            <button
              onClick={() => scrollToSection("solucao")}
              className="px-8 py-4 border-2 border-primary text-primary rounded-lg font-semibold hover:bg-primary/5 transition-all duration-300"
            >
              Entender a Solução
            </button>
          </div>

          <div className="flex items-center gap-6 pt-4">
            <div className="flex items-center gap-2">
              <CheckCircle size={20} className="text-secondary" />
              <span className="text-sm font-medium text-foreground">
                Blindagem Jurídica Completa
              </span>
            </div>
            <div className="w-px h-6 bg-border" />
            <span className="text-sm text-muted-foreground">Goiás</span>
          </div>
        </div>

        <div
          className="relative h-96 md:h-full flex items-center justify-center"
          style={{ width: "650px", height: "446px" }}
        >
          <div className="relative w-full h-full max-w-md">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl border border-primary/20" />
            <div className="absolute inset-4 rounded-xl overflow-hidden shadow-lg">
              <img
                src={DOCTOR_IMAGE_URL}
                alt="Dr. Magsowellington Alves - Especialista em Assessoria Jurídica"
                className="w-full h-full object-cover"
                style={{ width: "100%", height: "100%" }}
              />
            </div>
            <div className="absolute bottom-6 left-6 right-6 bg-background/95 backdrop-blur-sm border border-border rounded-lg p-4 shadow-lg">
              <p className="text-sm font-semibold text-primary mb-1">
                Dr. Magsowellington Alves
              </p>
              <p className="text-xs text-muted-foreground">
                Especialista em Assessoria Jurídica Estratégica
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
