import { ArrowRight, Mail, MapPin, Phone } from "lucide-react";
import { useState } from "react";

interface FormData {
  name: string;
  email: string;
  phone: string;
  company: string;
}

const reasons = [
  {
    number: "1",
    title: "Identificar Riscos Ocultos",
    description: "Descubra vulnerabilidades que podem custar caro",
  },
  {
    number: "2",
    title: "Quantificar Perdas",
    description: "Saiba exatamente onde sua empresa está perdendo dinheiro",
  },
  {
    number: "3",
    title: "Plano de Ação",
    description: "Receba recomendações estratégicas personalizadas",
  },
];

export default function CTA() {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    phone: "",
    company: "",
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Aqui você pode adicionar a lógica de envio do formulário
    console.log("Form submitted:", formData);
    setIsSubmitted(true);
    // Reset após 3 segundos
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: "", email: "", phone: "", company: "" });
    }, 3000);
  };

  return (
    <section id="cta" className="py-20 md:py-32 bg-gradient-to-br from-primary/10 to-secondary/10 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/5 rounded-full blur-3xl -z-10" />

      <div className="container">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">
              Diagnóstico Jurídico Gratuito: O Próximo Passo
            </h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Descubra agora onde sua empresa está{" "}
              <span className="text-secondary font-semibold">
                perdendo dinheiro
              </span>{" "}
              e onde estão os riscos ocultos.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-background border border-border rounded-lg p-8">
              <h3 className="text-2xl font-bold text-foreground mb-6">
                Solicite seu Diagnóstico
              </h3>

              {isSubmitted ? (
                <div className="bg-secondary/10 border border-secondary/30 rounded-lg p-8 text-center">
                  <div className="text-4xl mb-4">✓</div>
                  <h4 className="text-lg font-bold text-primary mb-2">
                    Obrigado!
                  </h4>
                  <p className="text-muted-foreground">
                    Entraremos em contato em breve para agendar seu diagnóstico
                    jurídico gratuito.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Nome Completo
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-card border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="Seu nome"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-card border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="seu@email.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Telefone
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-card border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="(62) 99999-9999"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Empresa
                    </label>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-card border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="Nome da sua empresa"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full px-6 py-4 bg-secondary text-secondary-foreground rounded-lg font-bold hover:opacity-90 transition-all duration-300 flex items-center justify-center gap-2 group text-lg"
                  >
                    Quero um Diagnóstico
                    <ArrowRight
                      size={20}
                      className="group-hover:translate-x-1 transition-transform"
                    />
                  </button>

                  <p className="text-xs text-muted-foreground text-center">
                    Fale agora com um especialista e proteja o futuro do seu
                    patrimônio.
                  </p>
                </form>
              )}
            </div>

            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-foreground mb-6">
                  Por que fazer o diagnóstico?
                </h3>
                <ul className="space-y-4">
                  {reasons.map((reason, index) => (
                    <li key={index} className="flex items-start gap-4">
                      <span className="w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0 mt-1">
                        <span className="text-secondary font-bold text-sm">
                          {reason.number}
                        </span>
                      </span>
                      <div>
                        <p className="font-semibold text-foreground">
                          {reason.title}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {reason.description}
                        </p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-card border border-border rounded-lg p-6 space-y-4">
                <h4 className="font-bold text-foreground">
                  Ou entre em contato direto:
                </h4>
                <div className="flex items-center gap-3">
                  <Phone size={20} className="text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">WhatsApp</p>
                    <p className="font-semibold text-foreground">
                      (62) 99976-4131
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Mail size={20} className="text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <p className="font-semibold text-foreground">
                      magsowellington@gmail.com
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
